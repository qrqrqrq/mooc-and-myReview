<template>
  <div class="position">
    <span class="iconfont position__icon">&#xe619;</span>
    北京理工大学国防科技园2号楼10层北京理工大学国防科技园2号楼10层
    <span class="iconfont position__notice">&#xe7e5;</span>
  </div>
  <div class="search">
    <span class="iconfont">&#xe7b3;</span>
    <span class="search__text"> 山姆会员商店优惠商品</span>
  </div>
  <div class="banner">
    <img
      class="banner__img"
      src="http://www.dell-lee.com/imgs/vue3/banner.jpg"
    />
  </div>
  <!-- 方式一div -->
  <!-- <div class="icons">
    <div class="icons__item" v-for="item in iconList" :key="item.id">
      <img :src="item.imageURL" class="icons__item__img" />
      <p class="icons__item__desc">{{ item.desc }}</p>
    </div>
  </div> -->

  <!-- 方式二div -->
  <div class="icons">
    <div class="icons__item" v-for="item in iconsList" :key="item.desc">
      <img
        class="icons__item__img"
        :src="`http://www.dell-lee.com/imgs/vue3/${item.imgName}.png`"
      />
      <p class="icons__item__desc">{{ item.desc }}</p>
    </div>
  </div>
  <div class="gap"></div>
</template>
<script>
export default {
  name: "StaticPart",
  // 方式一setup()：
  // setup() {
  //   const iconList = [
  //     {
  //       id: 1,
  //       imageURL: "http://www.dell-lee.com/imgs/vue3/超市.png",
  //       desc: "超市便利",
  //     },
  //     {
  //       id: 2,
  //       imageURL: "http://www.dell-lee.com/imgs/vue3/菜市场.png",
  //       desc: "菜市场",
  //     },
  //     {
  //       id: 3,
  //       imageURL: "http://www.dell-lee.com/imgs/vue3/水果店.png",
  //       desc: "水果店",
  //     },
  //     {
  //       id: 4,
  //       imageURL: "http://www.dell-lee.com/imgs/vue3/医药健康.png",
  //       desc: "医药健康",
  //     },
  //     {
  //       id: 5,
  //       imageURL: "http://www.dell-lee.com/imgs/vue3/家居.png",
  //       desc: "家居时尚",
  //     },
  //     {
  //       id: 6,
  //       imageURL: "http://www.dell-lee.com/imgs/vue3/蛋糕.png",
  //       desc: "烘培蛋糕",
  //     },
  //     {
  //       id: 7,
  //       imageURL: "http://www.dell-lee.com/imgs/vue3/鲜花.png",
  //       desc: "鲜花绿植",
  //     },
  //     {
  //       id: 8,
  //       imageURL: "http://www.dell-lee.com/imgs/vue3/签到.png",
  //       desc: "签到",
  //     },
  //     {
  //       id: 9,
  //       imageURL: "http://www.dell-lee.com/imgs/vue3/大牌免运.png",
  //       desc: "大牌免运",
  //     },

  //     {
  //       id: 10,
  //       imageURL: "http://www.dell-lee.com/imgs/vue3/红包.png",
  //       desc: "红包套餐",
  //     },
  //   ];
  //   return { iconList };
  // },

  // 方式二setup()，更优雅，复用性更高：
  setup() {
    const iconsList = [
      { imgName: "超市", desc: "超市便利" },
      { imgName: "菜市场", desc: "菜市场" },
      { imgName: "水果店", desc: "水果店" },
      { imgName: "鲜花", desc: "鲜花绿植" },
      { imgName: "医药健康", desc: "医药健康" },
      { imgName: "家居", desc: "家居时尚" },
      { imgName: "蛋糕", desc: "烘培蛋糕" },
      { imgName: "签到", desc: "签到" },
      { imgName: "大牌免运", desc: "大牌免运" },
      { imgName: "红包", desc: "红包套餐" },
    ];
    return { iconsList };
  },
};
</script>
<style lang="scss" scoped>
@import "../../style/variable.scss";
@import "../../style/mixins.scss";
.position {
  @include ellipsis;
  position: relative;
  padding: 0.16rem 0.24rem 0.16rem 0;
  line-height: 0.22rem;
  font-size: 0.16rem;

  .position__icon {
    // margin-right: 0.08rem;
    position: relative;
    top: 0.01rem;
    font-size: 0.2rem;
  }
  .position__notice {
    position: absolute;
    top: 0.17rem;
    right: 0;
    font-size: 0.2rem;
  }
  color: $content-font-color;
}
.search {
  margin-bottom: 0.12rem;
  line-height: 0.32rem;
  background-color: $search-bgColor;
  color: $search-font-color;
  border-radius: 0.16rem;

  .iconfont {
    position: relative;
    top: 0.04rem;
    padding: 0 0.12rem 0 0.16rem;
    font-size: 0.22rem;
  }
  &__text {
    display: inline-block;
    font-size: 0.14rem;
  }
}
.banner {
  // 防抖动,提前空出来了图片的位置
  height: 0;
  overflow: hidden;
  // 图片宽/高的比例
  padding-bottom: 25.4%;
  &__img {
    width: 100%;
  }
}
.icons {
  display: flex;
  flex-wrap: wrap;
  margin-top: 0.16rem;
  &__item {
    width: 20%;
    &__img {
      display: block;
      width: 0.4rem;
      height: 0.4rem;
      margin: 0 auto;
    }
    &__desc {
      margin: 0.06rem 0 0.16rem 0;
      text-align: center;
      color: $content-font-color;
    }
  }
}
.gap {
  margin: 0 -0.18rem;
  height: 0.1rem;
  background: $content-bgColor;
}
</style>
